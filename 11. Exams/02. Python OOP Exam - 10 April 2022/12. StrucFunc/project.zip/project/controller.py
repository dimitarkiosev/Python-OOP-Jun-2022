from project.player import Player
from project.supply.supply import Supply
from project.supply.food import Food
from project.supply.drink import Drink

class Controller:
    def __init__(self):
        self.players = list()
        self.supplies = list()

    def add_player(self, *players):
        added_players = list()
        for player in players:
            if player in self.players:
                continue
            self.players.append(player)
            added_players.append(player.name)
        return f'Successfully added: {", ".join(added_players)}'

    def add_supply(self, *supplies):
        self.supplies.extend(supplies)

    def sustain(self, player_name: str, sustenance_type: str):
        player = self.__find_player_by_name(player_name)
        if player is None:
            return

        if sustenance_type != 'Food' and sustenance_type != 'Drink':
            return
        idx, supply = self.__find_supply_by_type(sustenance_type)

        if supply is None:
            raise Exception(f'There are no {sustenance_type.lower()} supplies left!')

        # can move above
        if not player.need_sustenance:
            return f'{player.name} have enough stamina.'

        player.stamina = min(player.stamina + supply.energy, 100)
        self.supplies.pop(idx)

        return f'{player.name} sustained successfully with {supply.name}.'

    def duel(self, first_player_name: str, second_player_name: str):
        pl1 = self.__find_player_by_name(first_player_name)
        pl2 = self.__find_player_by_name(second_player_name)

        err_mes = ''
        if pl1.stamina == 0:
            err_mes = f'Player {pl1.name} does not have enough stamina.'
        if pl2.stamina == 0:
            err_mes = '\n' + f'Player {pl2.name} does not have enough stamina.'
        if err_mes:
            return err_mes.strip()

        if pl1.stamina > pl2.stamina:
            pl1, pl2 = pl2, pl1

        pl2.stamina = max((pl2.stamina - (pl1.stamina / 2)), 0)
        if pl2.stamina == 0:
            return f'Winner: {pl1.name}'

        pl1.stamina = max((pl1.stamina - (pl2.stamina / 2)), 0)
        if pl1.stamina == 0:
            return f'Winner: {pl2.name}'

        winner = pl1 if pl1.stamina > pl2.stamina else pl2

        return f'Winner: {winner.name}'


    def next_day(self):
        for pl in self.players:
            pl.stamina = max(pl.stamina - (pl.age * 2), 0)
            self.sustain(pl.name, 'Food')
            self.sustain(pl.name, 'Drink')

    def __str__(self):
        result = ''
        for pl in self.players:
            result += str(pl) + '\n'
        for sup in self.supplies:
            result += sup.details() + '\n'

        return result.strip()

    def __find_player_by_name(self, player_name):
        for player in self.players:
            if player.name == player_name:
                return player

    def __find_supply_by_type(self, sustenance_type):
        for idx in range(len(self.supplies) - 1, -1, -1):
            supply = self.supplies[idx]
            if supply.__class__.__name__ == sustenance_type:
                return (idx, supply)
        return (-1, None)