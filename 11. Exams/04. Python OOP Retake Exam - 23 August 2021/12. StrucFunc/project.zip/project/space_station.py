from project.astronaut.astronaut import Astronaut
from project.astronaut.biologist import Biologist
from project.astronaut.geodesist import Geodesist
from project.astronaut.meteorologist import Meteorologist
from project.astronaut.astronaut_repository import AstronautRepository
from project.planet.planet import Planet
from project.planet.planet_repository import PlanetRepository

class SpaceStation():
    def __init__(self, ):
        self.pr = PlanetRepository()
        self.ar = AstronautRepository()
        self.mission_completed = 0
        self.mission_not_completed = 0

    def add_astronaut(self, astronaut_type: str, name: str):
        astro = self.ar.find_by_name(name)
        if astro is not None:
            return f'{name} is already added.'

        if not astronaut_type in ['Biologist', 'Geodesist', 'Meteorologist']:
            raise Exception('Astronaut type is not valid!')

        if astronaut_type == 'Biologist':
            self.ar.add(Biologist(name))
        elif astronaut_type == 'Geodesist':
            self.ar.add(Geodesist(name))
        elif astronaut_type == 'Meteorologist':
            self.ar.add(Meteorologist(name))
        return f'Successfully added {astronaut_type}: {name}.'

    def add_planet(self, name: str, items: str):
        planet = self.pr.find_by_name(name)
        if planet is not None:
            return f'{name} is already added.'

        p1 = Planet(name)
        p1.items.extend(items.split(', '))
        self.pr.add(p1)
        return f'Successfully added Planet: {p1.name}.'

    def retire_astronaut(self, name: str):
        astro = self.ar.find_by_name(name)
        if astro is None:
            raise Exception(f"Astronaut {name} doesn't exist!")

        self.ar.remove(astro)
        return (f'Astronaut {name} was retired!')

    def recharge_oxygen(self):
        for astro in self.ar.astronauts:
            astro.increase_oxygen(10)

    def send_on_mission(self, planet_name: str):
        planet = self.pr.find_by_name(planet_name)
        if planet is None:
            raise Exception('Invalid planet name!')

        avail_astro = list()
        for astro in self.ar.astronauts:
            if astro.oxygen > 30:
                avail_astro.append((astro.name, astro.oxygen))
                if len(avail_astro) == 5:
                    break

        if len(avail_astro) == 0:
            raise Exception(f'You need at least one astronaut to explore the planet!')

        avail_astro.sort(key = lambda x : -x[1])

        astronauts_count = 0
        for ast, oxy in avail_astro:
            astronauts_count += 1
            astro = self.ar.find_by_name(ast)
            next_one = False

            while True:
                item = planet.items.pop()
                astro.backpack.append(item)
                astro.breathe()

                if len(planet.items) == 0:
                    self.mission_completed += 1
                    self.pr.remove(planet)
                    return f'Planet: {planet.name} was explored. {astronauts_count} astronauts participated in collecting items.'

                if astro.oxygen == 0:
                    next_one = True
                    break

            if next_one:
                continue

        self.mission_not_completed += 1
        return 'Mission is not completed.'



    def report(self):
        result = list()
        result.append(f"{self.mission_completed} successful missions!")
        result.append(f"{self.mission_not_completed} missions were not completed!")
        result.append("Astronauts' info:")
        for astro in self.ar.astronauts:
            result.append(f'Name: {astro.name}')
            result.append(f'Oxygen: {astro.oxygen}')
            if len(astro.backpack) > 0:
                result.append(f'Backpack items: {", ".join(astro.backpack)}')
            else:
                result.append(f'Backpack items: "none"')

        note = '\n'.join(result)
        return f'{note}'