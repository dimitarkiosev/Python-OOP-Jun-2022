from project.decoration.ornament import Ornament
from project.decoration.plant import Plant
from project.decoration.decoration_repository import DecorationRepository
from project.fish.base_fish import BaseFish
from project.fish.freshwater_fish import FreshwaterFish
from project.fish.saltwater_fish import SaltwaterFish
from project.aquarium.base_aquarium import BaseAquarium
from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.aquarium.saltwater_aquarium import SaltwaterAquarium
from project.controller import Controller


pl1 = Plant()
pl2 = Plant()
orn1 = Ornament()
orn2 = Ornament()

cc = Controller()
cc.add_aquarium('FreshwaterAquarium', 'Fresh')
cc.add_aquarium('SaltwaterAquarium', 'Salt')
for each in cc.aquariums:
    print(f'{each.name} - {each.capacity} - {each.decorations} - {each.fish}')
cc.add_decoration('Ornament')
cc.add_decoration('Ornament')
cc.add_decoration('Plant')
for each in cc.decorations_repository.decorations:
    print(f'{each.__class__.__name__} - {each.comfort} - {each.price}')

print(cc.insert_decoration('Fresh', 'Ornament'))
for each in cc.aquariums:
    print(f'{each.name} - {each.capacity} - {each.decorations} - {each.fish}')
for each in cc.decorations_repository.decorations:
    print(f'{each.__class__.__name__} - {each.comfort} - {each.price}')