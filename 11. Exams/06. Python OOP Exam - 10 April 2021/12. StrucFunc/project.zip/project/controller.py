from project.decoration.base_decoration import BaseDecoration
from project.decoration.ornament import Ornament
from project.decoration.plant import Plant
from project.decoration.decoration_repository import DecorationRepository
from project.fish.base_fish import BaseFish
from project.fish.freshwater_fish import FreshwaterFish
from project.fish.saltwater_fish import SaltwaterFish
from project.aquarium.base_aquarium import BaseAquarium
from project.aquarium.freshwater_aquarium import FreshwaterAquarium
from project.aquarium.saltwater_aquarium import SaltwaterAquarium

class Controller:
    def __init__(self):
        self.decorations_repository = DecorationRepository()
        self.aquariums = list()

    def add_aquarium(self, aquarium_type: str, aquarium_name: str):
        if aquarium_type != 'FreshwaterAquarium' and aquarium_type != 'SaltwaterAquarium':
            return 'Invalid aquarium type.'

        if aquarium_type == 'FreshwaterAquarium':
            self.aquariums.append(FreshwaterAquarium(aquarium_name))
        elif aquarium_type == 'SaltwaterAquarium':
            self.aquariums.append(SaltwaterAquarium(aquarium_name))
        return f'Successfully added {aquarium_type}.'

    def add_decoration(self, decoration_type: str):
        if decoration_type != 'Ornament' and decoration_type != 'Plant':
            return 'Invalid decoration type.'

        if decoration_type == 'Ornament':
            self.decorations_repository.add(Ornament())
        elif decoration_type == 'Plant':
            self.decorations_repository.add(Plant())
        return f'Successfully added {decoration_type}.'

    def insert_decoration(self, aquarium_name: str, decoration_type: str):
        decor = self.decorations_repository.find_by_type(decoration_type)
        if decor == 'None':
            return f"There isn't a decoration of type {decoration_type}."

        for aquarium in self.aquariums:
            if aquarium.name == aquarium_name:
                self.decorations_repository.remove(decor)
                aquarium.add_decoration(decor)
                return f"Successfully added {decoration_type} to {aquarium_name}."
        return

    def add_fish(self, aquarium_name: str, fish_type: str, fish_name: str, fish_species: str, price: float):
        if fish_type != 'FreshwaterFish' and fish_type != 'SaltwaterFish':
            return f"There isn't a fish of type {fish_type}."

        for aquarium in self.aquariums:
            if aquarium.name == aquarium_name:
                if (aquarium.__class__.__name__ == 'FreshwaterAquarium' and fish_type == 'SaltwaterFish') or (aquarium.__class__.__name__ == 'SaltwaterAquarium' and fish_type == 'FreshwaterFish'):
                    return 'Water not suitable.'
                if fish_type == 'FreshwaterFish':
                    aquarium.add_fish(FreshwaterFish(fish_name, fish_species, price))
                if fish_type == 'SaltwaterFish':
                    aquarium.add_fish(SaltwaterFish(fish_name, fish_species, price))

    def feed_fish(self, aquarium_name: str):
        fed_count = 0
        for aquarium in self.aquariums:
            if aquarium.name == aquarium_name:
                aquarium.feed()
                fed_count = len(aquarium.fish)

        return f'Fish fed: {fed_count}'

    def calculate_value(self, aquarium_name: str):
        value = 0
        for aquarium in self.aquariums:
            if aquarium.name == aquarium_name:
                for fish in aquarium.fish:
                    value += fish.price
                for decor in aquarium.decorations:
                    value += decor.price

        return f'The value of Aquarium {aquarium_name} is {value:.2f}.'

    def report(self):
        pass
